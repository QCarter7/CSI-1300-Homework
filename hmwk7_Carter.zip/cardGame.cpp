#include <iostream>
#include <vector>

using namespace std;


int main() {
    //create variables
    vector<int> deck;
    int count = 0;
   string temp;
    int temp_num = 0;
   
   //Keep on asking for number till they choose 14
while(temp_num != 14){
    cout << "Please enter a number:" << endl;
    cin >> temp_num;
    //if the number is in range add to vector
    if(temp_num>0 && temp_num<15){
 deck.push_back(temp_num);
 //for aces
 if(temp_num == 1 && deck.size()>1){
     deck.erase(deck.begin()+0);
      deck.erase(deck.begin()+0);
      count +=2;
 }else if(temp_num ==1){
      deck.erase(deck.begin()+0);
      count++;
      //for jacks, queens, and kings
 }else if(temp_num == 11 || temp_num == 12|| temp_num ==13 && deck.size()>1){
 deck.pop_back();



     count+=2;
 }else if(temp_num == 11 || temp_num == 12|| temp_num ==13){
 deck.pop_back();
  count ++;
  //for joker
 }else if(temp_num == 14){
     deck.pop_back(); 
      
 }
 
 //if the number is invalid 
}else{
    cout << "The number should be an integer between 1 and 14." << endl;
}
 }



//displays remaining cards
  cout << "Your remaining cards are: ";
for(int i = 0; i<deck.size(); i++){
cout <<deck.at(i)<<" "; 
}
cout << endl;
//displays how many you have
cout << "I have " << count << " card(s)." << endl;
//displays who won
if(count>deck.size()){
    cout << "I win!" << endl;
}else if(count<deck.size()){
    cout << "You win!" << endl;
}else if(count == deck.size()){
    cout << "Tie!" << endl;
}

    return 0;
}