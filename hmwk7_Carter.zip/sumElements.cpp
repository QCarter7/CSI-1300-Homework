#include<iostream>
#include<vector>

using namespace std; 


/*
1. check if start_index is larger than end_index
2. check if the index's are in bounds of the vector 
3. using a for loop go through each index and add up the sum
4. return the sum
*/
int sumElements( vector<int> vect  ,int start_index, int end_index){
int sum = 0;


if(start_index> end_index){
    return -1;
}else if(start_index<0 || end_index>=vect.size()){
    return -2;
}else{
for(int i =start_index; i<=end_index; i++){
    sum += vect.at(i);
}
return sum;
}

    
}


int main() 
{
	//checks to see if start_index or end_index is out of the vector bounds
vector<int> vect3 {2, 4, 6, 8, 10};
int start_index = 0, end_index = 5;
cout << sumElements(vect3, start_index, end_index) << endl;


//gives the sum of values between index 0 and index 4
vector<int> vect1{10, 20, 30, 40, 50, 60, 70, 80};
start_index = 0;
 end_index = 4;
cout << sumElements(vect1, start_index, end_index) << endl;

}