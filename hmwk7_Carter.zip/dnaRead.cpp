#include<iostream>
#include<vector>
#include <cstdlib>
#include <cctype>

using namespace std;





string dnaRead(vector<string> dna){
//variables
//Checks length of the dna
string temp;
//checks for the vector index for start of sequence and end of sequence
string temp2;
//string invalid for return
string invalid =  "Invalid sequence.";
//For sequnece
int start_idx = -1;
int end_idx = -1;

//checks if the vector element is a valid dna sequence
for(int i = 0; i<dna.size(); i++){
   temp = dna.at(i);
if(temp.length()!= 3){
    return invalid;
}else{
  for(int j = 0; j<temp.length(); j++){
      if(temp[i] != 'A' || temp[i] != 'T'|| temp[i] != 'G' || temp[i] != 'C'){
      }
  }
}
}
//finds start and end
for(int q = 0; q<dna.size(); q++){
    if(dna.at(q) == "ATG"){
        start_idx = q;
    }
      if(dna.at(q) == "TGA" ||dna.at(q) == "TAA" || dna.at(q) == "TAG" ){
        end_idx = q;
    }
}
if(start_idx == -1){
    return "";
}else{
for(int k = start_idx+1; k<end_idx; k++){
    temp2 += dna.at(k);
}
}   
    return temp2;
  
}



int main(){


vector<string> dna{"ATG", "TCA", "TAA"};
cout << dnaRead(dna) << endl;





}
