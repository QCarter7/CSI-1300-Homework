// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 2 - Problem 4


#include <iostream>

using namespace std; 

int main() {

int bCurrent = 25;
int vCurrent = 28;
int cmCurrent = 40;

int bFall = 5;
int vFall = 12;
int cmFall = 2;

int b;
int v;
int cm;

int days; 

cout << "How many days in the future would you like a prediction for?" << endl;
cin  >> days;

b = bFall * days + bCurrent;
v = vFall * days + vCurrent;
cm = cmFall * days + cmCurrent;

cout << "Breckenridge will have " << b << " inches, Vail will have " << v
<< " inches, and Copper Mountain will have " << cm << " inches." << endl;

}