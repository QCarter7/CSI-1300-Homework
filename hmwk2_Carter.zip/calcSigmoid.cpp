// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 2 - Problem 6




#include <iostream>
#include <cmath> 

using namespace std;

int main(){

double x;

cout << "Enter a value for x: " << endl;
cin >> x;

double S = 1/(1 + exp(-x));

cout << "The sigmoid for x=" << x << " is " <<
 S << endl;


}