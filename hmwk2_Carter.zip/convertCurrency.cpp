// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 2 - Problem 5



#include <iostream>

using namespace std; 

int main(){
double bolts = 0;
int gold_coins = 0;
int gem = 0;

     cout << "Enter the number of Bolts:" << endl;
    cin >> bolts;

if ( bolts >= 23){

gold_coins = bolts / 23;
bolts = bolts - (gold_coins * 23);
gem = gold_coins / 13;
gold_coins = gold_coins - (gem * 13);

cout << gem << " Gem(s) " << gold_coins << " GoldCoin(s) " << bolts << " Bolt(s)" << endl;

} else if (bolts < 23){
    cout << gem << " Gem(s) " << gold_coins << " GoldCoin(s) " << bolts << " Bolt(s)" << endl;
} 
                                                                                         

}