// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 2 - Problem 2


#include <iostream>

using namespace std;

int main(){
  string name;
    cout << "Please enter your name below: " << endl;
    getline(cin, name);
    
    cout << "Hello, " << name << "!" << endl;
    
    return 0;
}