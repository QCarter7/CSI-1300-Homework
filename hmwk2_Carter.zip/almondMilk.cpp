// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 2 - Problem 3


#include <iostream>
#include <cmath>
#include <iomanip>


using namespace std;

int main(){

    int x;  //side lenght
    int y;  //height
    

    cout << "What is the side length of the base of the carton in inches?" << endl;

    cin >> x;  //side lenght

    cout << "What is the height of the carton in inches?" << endl;

    cin >> y; //Height

  double z = (pow(x, 2) * y);
  
    double ounces = z * 0.55; 

     cout << "The carton has a volume of " <<
     fixed << setprecision(1)<< ounces << " ounces." << endl;
 


}