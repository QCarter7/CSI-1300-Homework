// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 8 - Problem 1


#include <iostream>
#include <cassert>

using namespace std; 

/*
1. Takes input from user
2. Assign input to another variable
3. If input is 0 then return 0
4. If the input is a single digit then return digit
5. If the input is multiple go through fibinoci sequence till there is one digit
*/
int digitsSuperSumRecursive(int N){
    
int &r = N;

if(r ==0){
return r;
}
if(r<=9){
    return r;
    assert(r != 10);
}else{
  int j = (r%10+digitsSuperSumRecursive(r/10));
return (j%10+digitsSuperSumRecursive(j/10));
}
    
}


int main(){
//variables
    int input = 0;
//starting display
cout << "Enter A number larger than 0: " << endl;
//doesnt accept a number lower than 0
while(input<0){
cin >> input;
}
//make sure that the number isnt 0
assert(input!=0);
cout << digitsSuperSumRecursive(input) << endl;
}