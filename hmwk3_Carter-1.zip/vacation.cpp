// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 3 - Problem 2


#include <iostream>
using namespace std;

int main(){

    //variables
    double budget; 
    char trans;
     
     //Starting question
    cout << "What is your budget?" << endl;
    cin >>budget;

    //Checks if budget is greater than 0 (not negative)
    if (budget >0){
     cout << "What mode of transportation would you like to take (B, T, or A)?" << endl;
    cin >> trans;
    
    //checks if selection is upper case
   if (isupper(trans)){
       
       switch(trans){
           
           //Bus
           case 'B': 
           budget = budget - 175.25;
           if(budget >=0){
            //Budget is still postive
               cout << "Yes, this vacation is within your budget!" << endl;
           }else if (budget < 0){
            //budget is less negative
               cout << "Sorry, this vacation is outside your budget." << endl;
           }
           break;
           
           //Train
           case 'T': 
           budget = budget - 240.66;
           if(budget >=0){
               cout << "Yes, this vacation is within your budget!" << endl;
           }else if (budget < 0){
               cout << "Sorry, this vacation is outside your budget." << endl;
           }
           break;
           
           //Airplane 
           case 'A': 
           budget = budget - 350.93;
           if(budget >=0){
               cout << "Yes, this vacation is within your budget!" << endl;
           }else if (budget < 0){
               cout << "Sorry, this vacation is outside your budget." << endl;
           }
           break;
           
           
       }
       //if lettter is lower case
   }else {
   cout << "Please enter a valid input." << endl;
   }
    

    
    //if budget is negative
}else{
    cout << "Please enter a valid input."<< endl;
    
}
}