// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 3 - Problem 5


#include <iostream>
using namespace std; 

int main(){
//variables for department, class, and section
    int dept;
    int class_input;
    int section;

//First user input
cout << "Select a department: (1)Computer Science (2)Math (3)Science" << endl;
cin >> dept;

//This if statement test witch department the user chose and gives out the classes
if((0<dept) && (dept<=3)){

    switch(dept){
        case 1:
        cout<< "Select a class: (1)Starting Computing (2)Data Structures (3)Algorithms"
         << endl;
         cin >> class_input; 
         break;
         case 2:
         cout<< "Select a class: (1)Calculus 1 (2)Calculus 2 (3)Linear Algebra"
         << endl;
         cin >> class_input; 
          break;
         case 3:
           cout<< "Select a class: (1)General Chemistry 1 (2)Physics 1"
         << endl;
         cin >> class_input; 
          break;
         default: 
         cout <<"Please enter a valid input." << endl; break;
    }
}else {
    cout << "Please enter a valid input." << endl;
    return 0;
}


//This if statement tests which class the user chose and gives out the sections
if((0<class_input) && (class_input<=3)){
switch(dept){
    //dept 1
case 1:
    switch(class_input){
        case 1:
        cout<< "Select a section: (1)Section 100 (2)Section 200"
         << endl;
         cin >> section; 
         break;
         case 2:
         cout<< "Select a section: (1)Section 101 (2)Section 201"
         << endl;
         cin >> section; 
          break;
         case 3:
           cout<< "Select a section: (1)Section 102 (2)Section 202"
         << endl;
         cin >> section; 
          break;
         default: 
         cout <<"Please enter a valid input." << endl; break;
    }
    break;
// dept 2
case 2:
switch(class_input){
        case 1:
        cout<< "Select a section: (1)Section 400 (2)Section 500"
         << endl;
         cin >> section; 
         break;
         case 2:
         cout<< "Select a section: (1)Section 401 (2)Section 501"
         << endl;
         cin >> section; 
          break;
         case 3:
           cout<< "Select a section: (1)Section 402 (2)Section 502"
         << endl;
         cin >> section; 
          break;
         default: 
         cout <<"Please enter a valid input." << endl; break;
    }
    break;
// dept 3
        case 3:
        switch(class_input){
        case 1:
        cout<< "Select a section: (1)Section 700 (2)Section 800"
         << endl;
         cin >> section; 
         break;
         case 2:
         cout<< "Select a section: (1)Section 701 (2)Section 801"
         << endl;
         cin >> section; 
          break;
         default:
          cout<<"Please enter a valid input." << endl;
         return 0; break;
    }
    break;

}



}else {
    cout << "Please enter a valid input." << endl;
    return 0;
    
}


if((0<section) && (section<=3)){
switch(dept){
//dept 1 
    case 1:

    switch(class_input){
        //class 1 in dept 1
        case 1:
    switch(section){
case 1:
cout << "You've been enrolled in Section 100 of Starting Computing!" << endl; break;
case 2: 
cout << "You've been enrolled in Section 200 of Starting Computing!" << endl; break;
    }
    break;
    //class 2 in dept 1
    case 2:
    switch(section){
        case 1:
        cout << "You've been enrolled in Section 101 of Data Structures!" << endl; break;
        case 2:
        cout << "You've been enrolled in Section 201 of Data Structures!" << endl; break;
    }
    break;
    //class 3 in dept 1
    case 3:
    switch(section){
        case 1:
        cout << "You've been enrolled in Section 102 of Algorithms!" << endl; break;
        case 2:
        cout << "You've been enrolled in Section 202 of Algorithms!" << endl; break;
    }
    }
    break;

    //Dept 2
    case 2:

 switch(class_input){
        //class 1 in dept 2
        case 1:
    switch(section){
case 1:
cout << "You've been enrolled in Section 400 of Calculus 1!" << endl; break;
case 2: 
cout << "You've been enrolled in Section 500 of Calculus 1!" << endl; break;
    }
    break;
    //class 2 in dept 2
    case 2:
    switch(section){
        case 1:
        cout << "You've been enrolled in Section 401 of Calculus 2!" << endl; break;
        case 2:
        cout << "You've been enrolled in Section 501 of Calculus 2!" << endl; break;
    }
    break;
    //class 3 in dept 2
    case 3:
    switch(section){
        case 1:
        cout << "You've been enrolled in Section 402 of Linear Algebra!" << endl; break;
        case 2:
        cout << "You've been enrolled in Section 502 of Linear Algebra!" << endl; break;
    }
    }
    break;

    //dept 3
    case 3:

     switch(class_input){
        //class 1 in dept 3
        case 1:
    switch(section){
case 1:
cout << "You've been enrolled in Section 700 of General Chemistry 1!" << endl; break;
case 2: 
cout << "You've been enrolled in Section 800 of General Chemistry 1!" << endl; break;
    }
    break;
    //class 2 in dept 3
    case 2:
    switch(section){
        case 1:
        cout << "You've been enrolled in Section 701 of Physics 1!" << endl; break;
        case 2:
        cout << "You've been enrolled in Section 801 of Physics 1!" << endl; break;
        default:
        return 0;
    }
    break;
     
    }
break;

    }






} else if(section>3){
     cout<<"Please enter a valid input." << endl;
    return 0;
    
}else if (section<0){
 cout<<"Please enter a valid input." << endl;
    
}else{
     cout<<"Please enter a valid input." << endl;
}


}




