// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 3 - Problem 4



#include <iostream>

using namespace std;

int main(){
    //variables
    double a;
    double b; 
    double c;

//Starting question
cout << "Enter wifi speeds over the last 3 classes:" << endl;
cin >>a>>b>>c;

if((a<0)||(b<0)||(c<0)){
    //If any wifi speed is negative
cout<<"Please enter a valid input."<< endl;
}else if((a<b)&&(b<c)){
    //if the numbers are increasing
    cout<< "The wifi is getting faster!" <<endl;
}else if((a>b)&&(b>c)){
    //if the numbers are decreasing
    cout << "The wifi is getting slower!" << endl;
}else {
    //the numbers are out of order (not decreasing or increasing)
    cout << "The wifi speed is changing unpredictably." << endl;
}
}