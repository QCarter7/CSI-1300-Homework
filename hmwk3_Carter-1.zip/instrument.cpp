// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 3 - Problem 6



#include <iostream>
using namespace std;

int main(){
//variables
    int category;
    //type of instrument 
    int type;
    // Price of instrument 
    int price;

//First question 
    cout << "Select a category: (1)Brass (2)Woodwind (3)Percussion" << endl;
    cin >> category;

//Catagory selection
    switch(category){
        case 1:
        cout << "Select an instrument: (1)Trumpet (2)Trombone" << endl; 
        cin >> type;
        //user input for what instrument
switch(type){
    case 1:
    cout << "Your instrument will be $350." << endl; break;
    case 2:
     cout << "Your instrument will be $400." << endl; break;
     default:
      cout << "Please enter a valid input." << endl; break;
}
break;

        case 2:
        cout << "Select an instrument: (1)Flute (2)Saxophone" << endl;
        cin >> type; 
switch(type){
    case 1:
    cout << "Your instrument will be $325." << endl; break;
    case 2:
     cout << "Your instrument will be $425." << endl; break;
     default:
      cout << "Please enter a valid input." << endl; break;
}
break;


        case 3:
        cout << "Select an instrument: (1)Snare Drum (2)Cymbals" << endl;
        cin >> type; 
switch(type){
    case 1:
    cout << "Your instrument will be $275." << endl; break;
    case 2:
     cout << "Your instrument will be $200." << endl; break;
     default:
      cout << "Please enter a valid input." << endl; break;
}
break;

        default:
        cout << "Please enter a valid input." << endl;
        return 0; break;
    }


}