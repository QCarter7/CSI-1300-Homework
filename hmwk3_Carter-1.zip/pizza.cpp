// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 3 - Problem 3




#include <iostream>

using namespace std; 

int main(){
//varibles 
char size; 
double base_price; 
double topping_price; 
int toppings;
double total;

//starting Question
cout << "What size pizza would you like to order?" << endl;
cin >> size;


switch(size){
//small
    case 'S':
    cout<<"How many toppings do you want?" << endl;
cin >> toppings;
if(toppings>=0){
    topping_price = .75;
    total = (toppings * topping_price)+4.99; 
    cout << "Your total is $" << total << endl; 
}else{
    cout << "Please enter a valid input." << endl;
}
break;
//medium 
    case 'M':
 cout<<"How many toppings do you want?" << endl;
cin >> toppings;
if(toppings>=0){
    topping_price = 1.50;
    total = (toppings * topping_price)+5.99; 
    cout << "Your total is $" << total << endl; 
    }else{
    cout << "Please enter a valid input." << endl;
}
break;
//large 
    case 'L':
 cout<<"How many toppings do you want?" << endl;
cin >> toppings;
if(toppings>=0){
    topping_price = 2.25;
    total = (toppings * topping_price)+6.99; 
    cout << "Your total is $" << total << endl;
    }else{
    cout << "Please enter a valid input." << endl;
}
break;

//Wrong input by user
    default: 
    cout << "Please enter a valid input." << endl; break;
}

}