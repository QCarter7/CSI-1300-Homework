// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 6 - Problem 3


#include <iostream>
#include <string>
#include <fstream>

using namespace std;

/*
1. Declare the variables count a and second
2. Checks the length to see if string is possible (if not return 0)
3. loops through the testcase to find where the seporator is and adds to second
4. impliments size and counts how many seporators there are
5. compare the two values and return either -1 for no more seporators left or the amount of seporators
*/
int split(string testcase, char separator, string arr[], int size){
int count= 0;
int second = 0;

//to see if there is a string to test
if(testcase.length() == 0){
    return 0;
}
for(int j = 0; j<testcase.length(); j++ ){
    //if seperator is found in the string add to how many seporators there is
     if(separator ==testcase[j]){
         second++;
     }
}

//if you find seperpator for the given amount of times then add to count
for(int i = 0; i<testcase.length(); i++ ){
    if(separator ==testcase[i]&&count!=size){
        count++;
        i+=1;
    }
    //return conunt of seporators 
     arr[count] += testcase[i];
}
//return values if there more seporators left 
if(count+1>size){
    return -1;
//return value if they are no more seporators to sperorate. 
}else if(count>=0){
    assert(count+1==size);
    return count+1;
}
return 0;
}


/*
1.Open file
2.Check to see if file opened succesfully
3. declare varibles if filed opened (if not return -1)
4. get each line in the file put it into the function split
5. if fuction returns the declared size add to count of posts
6. close file
7. reuturn post count
*/
int readPosts(string file_name){
    //For file
 ifstream fin;
    //Opens file input
 fin.open(file_name);
if(fin.is_open()){
    //input string 1.
string testcase; 
//check commas 2. 
char separator = ',';
//number of elements that can be in a array 3. 
int size = 3;
//the number of elements that can be stored in the array 4. 
string arr[size];

//int split count
int count_1=0;

while(getline(fin, testcase)){
    //Tests if split return size we want the element to be
  if(split(testcase,separator,arr,size)==size){
    //count posts
   assert(split(testcase,separator,arr,size)==size);
      assert(split(testcase,separator,arr,size)!=4);
   count_1++; 
  }
}

fin.close();
return count_1;
     }else{
        return -1;
     }
}



int main(){

string file_name = "posts.txt";


cout << "Number of posts: " << readPosts(file_name) << endl;
assert(readPosts(file_name) == 7);
assert(readPosts(file_name) != '\0');
}