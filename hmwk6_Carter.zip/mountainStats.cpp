// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 6 - Problem 2



#include <iostream>
#include <fstream> //for files
#include <cassert> //test cases
#include <string>
#include <iomanip>
#include <cctype>
#include <algorithm>

using namespace std; 


//void function no return 
//This funciton open a file and goes through each line 
//it seperates the number data from the line and compares the values
//it then returns the sub string of the first data to the highest and lowest string in the end sentence 
//all variables are declared inside function

void printMountainStats(string filename){
    //variables
    ifstream fin;
    //Opens file input
     fin.open(filename);
     assert(fin.open(filename)==true);
     if(fin.is_open()){
string line;

//counts number of lines in file
int count = 0;
//stores highes and lowest values
int lowest = 100000;
int highest = 0;
//stores string name for data
string highest_string;
string lowest_string;

//stores number data in array
int num_arr[line.length()];
int num_idx=0;
//checks each line in the file
while(getline(fin, line)){
//start strings 
string temp; 

//if the line has nothing on it skip
if(line != ""){
    //do nothing to spacing 
    for(int i =0; i<line.length(); i++){
if(line[i] == ' '){
    continue;
}
//take divider and turn into space
if(line[i] == '|'){
    line[i] = ' ';
}
//takes the line from the ' ' to end
if(line[i] == ' '){
    temp = line.substr(i+1,line.length());
    //Checks what is the highest and smallest
    //changes the temp to a integer
num_arr[num_idx] = stoi(temp);


//checks for highest number in array
    if(num_arr[num_idx]>highest){
        highest = num_arr[num_idx];
        highest_string = line.substr(0,i);
num_idx++;
//checks for lowest number in array
}else if(num_arr[num_idx]<lowest){
    lowest = num_arr[num_idx];
    lowest_string = line.substr(0,i);
}

}

}
//counter for lines in file
count++;

}
}

assert(fin.is_open());
assert(count != 4);


//Display answer
cout << "Number of lines read: " <<count <<"." << endl; 
//display and check value of highest
    cout << "Tallest mountain: " <<highest_string<< " at "<< highest<<" feet."<< endl;
    assert(highest == 14114);

    //Display and check the value of lowest
    cout <<"Shortest Mountain: " <<lowest_string << " at " <<lowest <<" feet." << endl;
assert(lowest == 13894);
    //close file
    fin.close();
    assert(fin.close());
    //If file can be opened
     }else{
        cout << "Could not open file." << endl;
      assert(!fin.isopen())
     }
}
int main(){
//variables
    string filename ="mountain_data.txt";

//user request
/*
cout << "Please Enter file name: " << endl;
cin >> filename;
*/

//Takes computer into funciton
printMountainStats(filename);

}