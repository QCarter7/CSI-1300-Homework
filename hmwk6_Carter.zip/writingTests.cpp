// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 6 - Problem 1


#include <iostream>
#include <string>
#include <fstream>
#include <cassert>

using namespace std;

/*
    1. Counts the number of given characters
    2. found in the given input string. 
*/
int countCharacters(string input, char c)
{
    int count = 0;
    int input_len = input.length(); // store length of string in variable
    // loop through the string to check every character
    for (int i = 0; i < input_len; i++)
    {
        if (input[i] == c) // add one to total count if it matches desired character
            count += 1;
    }

    return count;
}

/*
   1. Takes a given file name and reads the contents. 
    2. Counts the occurences of letter on each line.
    3. Prints the line number and the number of occurences for each line.
   4.  At the end, prints the total number of occurences.
   5. Returns true if the total number of occurences was greater than 20.

*/
bool readFile(string file_name, char letter)
{
    bool result = false;  // final result to return at end
    int total_count = 0;  // counts total occurrences of letter
    int line_count = 0;   // count of occurrences of letter for a single line
assert(result==false);
    string line;    // variable for storing each line as we read it
    ifstream fin;   // file input stream

    fin.open(file_name); // Open input file
    
    if (fin.fail())
    {
        cout << "File couldn't be opened!" << endl;
        result = false;
        assert(result==false);
    }
    else
    {
        // read every line of file, count number of characters on each line
        int line_number = 0;
        while (!fin.eof()) // continue looping as long as there is data to be processed in the file
        {
            line_number += 1;
            getline(fin, line);

            line_count = countCharacters(line, letter);
            total_count += line_count;

            cout << "Line: " << line_number << ", Occurences: " << line_count << endl;
        } 
    
        // print the total count to user
        cout << "Total occurences: " << total_count << endl;

        // update result of function -- is true if total count greater than 20
        result = total_count > 20;

        // close files
        fin.close();
    }

    return result;
}

int main()
{
    // write at least 6 additional test cases to test countCharacters()
  

    //Test for how many a's in the sentence is true
assert(countCharacters("And only herald to the gaudy spring", 'a')==2);

    //Test for how many A's in the sentence is true
assert(countCharacters("And only herald to the gaudy spring", 'A')==1);

    //Test for how many e's in the sentence is true
assert(countCharacters("That thereby beauty's rose might never die,", 'e')==7);

 //Test for how many e's in the sentence is true
assert(countCharacters("That thereby beauty's rose might never die,", 'e')==7);

 //Test for how many e's in the sentence is true
assert(countCharacters("That thereby beauty's rose might never die,", 'e')>=7);

 //Test for how many e's in the sentence is true
assert(countCharacters("That thereby beauty's rose might never die,", 'e')==7);


assert(countCharacters("That thereby beauty's rose might never die,", 't')!=8);

//Test for 

    // write at least 6 additional test cases to test readFile()
 
 //checks to see how many times c is useed in the whole file
     assert(readFile("shakespeare_sonnet.txt", 'c') != true);

     // Checks to see how many times b is used in the file
 assert(readFile("shakespeare_sonnet.txt", 'r') == true);

//Checks to see how many times e is used in the file
    assert(readFile("shakespeare_sonnet.txt", 'e') == true);

    // Checks to see how many times a is used in the file
assert(readFile("shakespeare_sonnet.txt", 'a') == true);

    // Checks to see how many times o is used in the file
assert(readFile("shakespeare_sonnet.txt", 'o') == true);

    // Checks to see how many times i is used in the file
assert(readFile("shakespeare_sonnet.txt", 'i') == true);


    return 0;
}