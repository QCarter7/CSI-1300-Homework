#include <iostream>
#include <fstream>
#include <algorithm>
#include <cmath>
#include <string>
#include <cassert>
#include <cctype>
#include <iomanip>


using namespace std;

/*
1. Declare the variables count a and second
2. Checks the lenght to see if string is possible (if not return 0)
3. loops through the testcase to find where the seporator is and adds to second
4. impliments size and counts how many seporators there are
5. compare the two values and return either -1 for no more seporators left or the amount of seporators
*/
int split(string testcase, char separator, string arr[], int size){
int count= 0;
int second = 0;

//to see if there is a string to test
if(testcase.length() == 0){
    return 0;
}
for(int j = 0; j<testcase.length(); j++ ){
    //if seperator is found in the string add to how many seporators there is
     if(separator ==testcase[j]){
         second++;
     }
}

//if you find seperpator for the given amount of times then add to count
for(int i = 0; i<testcase.length(); i++ ){
    if(separator ==testcase[i]&&count!=size){
        count++;
        i+=1;
    }
    //return conunt of seporators 
     arr[count] += testcase[i];
}
//return values if there more seporators left 
if(count+1>size){
    return -1;
//return value if they are no more seporators to sperorate. 
}else if(count>=0){
  
   
    return count+1;
}

return 0;
}


int readRestaurantData(string file_name, string restaurants[], int ratings[][3], int arrSize){
//to open file
ifstream fin;
//temporary strings
string line;
string temp;
string test[16];
//line count
int count_1 = 0;
//number of elements that can be in a array 3. 
int size = 4;
//the number of elements that can be stored in the array 4. 
string arr[size];
//Opens file
fin.open(file_name);
//Checks to see if file is open
if(fin.is_open()){
//variables 
int idx = 0;
int idx2 = 0;
int idx3 = 0;

//goes thorugh file and gets every line
while(getline(fin, line)){

   //input string 1.
string testcase = line; 

//check commas 2. 
char separator = '~';

//checks to see if line has anything on it
if(line != ""){

//split function 
if(split(testcase, separator,arr, size)==size){
testcase += '~';
//checks to see if were still useing tha same separartor

assert(separator = '~');
//for loop going thourght each tested line
for (int i= 0; i<testcase.length(); i++){
//if it doesnt eqaul seperator put into a string
if(testcase[i]!= '~'){
    temp+=testcase[i];
  //when it does equal seperator put temp into test
}else{
   test[idx] = temp;
    temp = "";
    idx++;
}
}



//counting number of lines
count_1++;
}

}else{
    continue;
}
}
//displays answer
cout << "Number of lines: " << count_1 <<"." <<endl;
for (int j = 0; j<16; j+=4){
   
    cout << "names [" << idx2 <<"]  = "<< test[j]  <<endl;
    idx2++;
}
for(int q = 1; q<=count_1; q++){
   
    
        cout << "food quality: " << test[idx3+1] << " / 10, cleanliness: " << test[idx3+2] << " / 5, wait time: " << test[idx3+3] << " / 5" << endl;
idx3+=4;
}


return count_1;
//if you cant open file
}else{
    cout<< "Could not open file." << endl;
    return 0;
}




return 0;
}



int main(){

//Declare variables
string file_name = "restaurant_samples.txt";
int arrSize = 3;
string restaurants[arrSize];
int ratings[arrSize][3];
 
//Go Reastaurant data funtion to read file
readRestaurantData(file_name,restaurants,ratings,arrSize);

}