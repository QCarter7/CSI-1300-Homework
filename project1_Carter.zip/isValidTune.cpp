// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Project 1 - Problem 2


#include <iostream> 
using namespace std;

//Checks every two places for a valid note
int isValidNote(string note){
   
    if(note.length() <= 2 ){

if(note[0] == 'D' || note[0] == 'A'|| note[0] == 'B' || note[0] == 'C'||  note[0] == 'E'|| note[0] == 'F'|| note[0] == 'G'){
    return true;
   
}else{
    return false;
}


    }else{
        return false;
    }
}

//Checks the entire length of the tune by using isValidNote
bool isValidTune(string note){
    bool Final = true;
for (int i=0; i<note.length(); i+=2){


if(isValidNote(note.substr(i,2)) == true){
    Final = true;
}else{
 return false;
}
}
return Final;
}


int main(){
    
    //varibales 
    string note;
cout << "Please Enter a Valid Tune:" << endl;
cin >> note;

//displays return value of function
cout << isValidTune(note) << endl;
}