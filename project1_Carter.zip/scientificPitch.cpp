#include <iostream>
#include <algorithm>
#include <iomanip>
using namespace std;

//compares two scores to see how similar they are
double tuneSimilarity(string tune1, string tune2){
    //variables
float count = 0;
float diff = 0;
float match = 0;
float o = 0;
float final = 0;

//checks to see if the lengths are the same
if(tune1.length() == tune2.length()){
    for(int i = 0; i<tune1.length(); i+=2){

        //calculates similarity
        if(tune1.substr(i,2) == tune2.substr(i,2)){
            count++;
            match++;
        }
            if(tune1.substr(i,1) == tune2.substr(i,1) && tune1.substr(i+1,1) != tune2.substr(i+1,1)){
                match++;
            }else if(tune1.substr(i,1) != tune2.substr(i,1) && tune1.substr(i+1,1) != tune2.substr(i+1,1)){
            diff--;
            }

}
}else{
    return 0;
}
//add all the calculations
o = tune1.length()/2;
final += (match/o)+count+diff;
return final;
}

//Gives best score similarity
double bestSimilarity(string inputTune, string targetTune){
    //variables
    double original=-100000;
    double new_high; 
    //checks to see if input tune is shorter than the target tune
    if(inputTune.length()>=targetTune.length()){   
        for(int i = 0; i<=(inputTune.length()-targetTune.length()); i++){
            
      //computes similarity score
         new_high = tuneSimilarity(inputTune.substr(i,targetTune.length()),targetTune);    
//Keeps highest score
if(new_high>original){
    original = new_high;
}
        }
        }else{
        return 0;
    }  
return original;
}

//orders the tunes by using their best similarity scores
string printTuneRankings(string tune1, string tune2, string tune3, string targetTune){
    //variables 
   double tune1_score = 0;
   double tune2_score = 0;
   double tune3_score = 0;
   string sentence;
  
   //gets best score from other function 
      tune1_score = bestSimilarity(tune1, targetTune);
       tune2_score = bestSimilarity(tune2, targetTune);
        tune3_score = bestSimilarity(tune3, targetTune);
        
    //puts the scores into an array and sorts from smallest to largest
    double arr[] ={tune1_score, tune2_score,tune3_score};
 int len = sizeof(arr)/sizeof(arr[0]);
sort(arr, arr+len);


//Creates sentece structure for differnet possiblities 
if(tune1_score == arr[2] && tune2_score == arr[1] && tune3_score == arr[0] && tune1_score != tune2_score){
    sentence = "1) Tune 1, 2) Tune 2, 3) Tune 3";
}
if(tune1_score == arr[0] && tune2_score == arr[1] && tune3_score == arr[2] && tune1_score != tune2_score){
    sentence = "1) Tune 3, 2) Tune 2, 3) Tune 1";
}
if(tune1_score == arr[2] && tune2_score == arr[0] && tune3_score == arr[1] && tune1_score != tune2_score){
    sentence = "1) Tune 1, 2) Tune 2, 3) Tune 3";
}
if(tune1_score == arr[2] && tune2_score == arr[0] && tune3_score == arr[1] && tune1_score == tune3_score){
    sentence = "1) Tune 1, 2) Tune 3, 3) Tune 2";
}
if(tune1_score == arr[2] && tune2_score == arr[1] && tune3_score == arr[0] && tune1_score == tune3_score){
    sentence = "1) Tune 1, 2) Tune 2, 3) Tune 3";
}
if(tune1_score == arr[2] && tune2_score == arr[0] && tune3_score == arr[1] && tune1_score != tune2_score){
    sentence = "1) Tune 1, 2) Tune 3, 3) Tune 2";
}
if(tune1_score == arr[2] && tune2_score == arr[0] && tune3_score == arr[1] && tune2_score == tune3_score){
    sentence = "1) Tune 1, 2) Tune 2, 3) Tune 3";
}
if(tune1_score == arr[1] && tune2_score == arr[0] && tune3_score == arr[2] && tune1_score == tune2_score){
    sentence = "1) Tune 1, 2) Tune 2, 3) Tune 3";
}
if(tune1_score == arr[2] && tune2_score == arr[1] && tune3_score == arr[0] && tune1_score == tune2_score && tune1_score != tune3_score){
    sentence = "1) Tune 1, 2) Tune 2, 3) Tune 3";
}
if(tune1_score == arr[1] && tune2_score == arr[0] && tune3_score == arr[2] && tune1_score == tune2_score && tune1_score != tune3_score){
    sentence = "1) Tune 3, 2) Tune 1, 3) Tune 2";
}
if(tune1_score == arr[1] && tune2_score == arr[2] && tune3_score == arr[0] && tune1_score == tune3_score && tune1_score != tune2_score ){
    sentence = "1) Tune 2, 2) Tune 1, 3) Tune 3";
}



return sentence;
}


//Checks a note ( A note is A-G and 0-9 ex: A7)
int isValidNote(string note){
   
    if(note.length() <= 2 ){

if(note[0] == 'D' || note[0] == 'A'|| note[0] == 'B' || note[0] == 'C'||  note[0] == 'E'|| note[0] == 'F'|| note[0] == 'G'){
    return true;
   
}else{
    return false;
}


    }else{
        return false;
    }
}

//Checks if its valid tune by using valid note for each section
bool isValidTune(string note){
    bool Final = true;
for (int i=0; i<note.length(); i+=2){

//uses other function
if(isValidNote(note.substr(i,2)) == true){
    Final = true;
}else{
 return false;
}
}
return Final;
}



int main(){
    //variables
    int user;
    string inputTune;
    string targetTune;
    string tune1;
    string tune2;
    string tune3;
    double final;
    string final_string;
    
    
    //Menu Repeats till quit option is selected 
  while(true) {
    cout << "--- Menu ---\n"<< "1. Calculate similarity between two tunes.\n" <<"2. Calculate best similarity between two tunes of potentially different lengths.\n"
    << "3. Print three input tunes in order from most to least similar to the target tune.\n"<< "4. Exit." << endl;
    cout << "Please enter your choice (1 - 4):" << endl;
    cin >> user;
//Checks if the input is between 1 and 4
if(1<=user&& user<=4){
 switch(user){
    //First option
    case 1:
    cout << "Please enter the first tune:" << endl;
    cin >> tune1;
    //Checks if the input is valid
     if(isValidTune(tune1)== false){
     do{
       cout << "Invalid input. Please enter a tune in valid SPN:" << endl;
       cin >> tune1;
   }while(isValidTune(tune1) != true);
    }
cout << "Please enter the second tune:" << endl;
    cin >> tune2;
     if(isValidTune(tune2)== false){
     do{
       cout << "Invalid input. Please enter a tune in valid SPN:" << endl;
       cin >> tune2;
   }while(isValidTune(tune2) != true);
    }
    
   final = tuneSimilarity(tune1, tune2);
   //gives back the score from function
   cout << "The similarity score is " << setprecision(2) << fixed << final << endl;
    break;
    //second option 
    case 2:
   cout<<"Please enter the input tune:" << endl;
   cin >> inputTune;
   //checks if the input is a valid tune
    if(isValidTune(inputTune)== false){
     do{
       cout << "Invalid input. Please enter a tune in valid SPN:" << endl;
       cin >> inputTune;
   }while(isValidTune(inputTune) != true);
    }
    
   cout<<"Please enter the target tune:" << endl;
   cin >> targetTune;
    if(isValidTune(targetTune)== false){
     do{
       cout << "Invalid input. Please enter a tune in valid SPN:" << endl;
       cin >> targetTune;
   }while(isValidTune(targetTune) != true);
    }
   //Gives back input from function
 final =  bestSimilarity(inputTune, targetTune);
   cout<< "The best similarity score is: "<< setprecision(2) << fixed << final<< endl;
   break;
   //Third option
   case 3:
   cout << "Please enter the first tune:" << endl;
   cin >> tune1;
   if(isValidTune(tune1)== false){
   do{
       cout << "Invalid input. Please enter a tune in valid SPN:" << endl;
       cin >> tune1;
   }while(isValidTune(tune1) == false);
   }
   cout << "Please enter the second tune:" << endl;
   cin >> tune2;
      if(isValidTune(tune2)== false){
     do{
       cout << "Invalid input. Please enter a tune in valid SPN:" << endl;
       cin >> tune2;
   }while(isValidTune(tune2) != true);
      }
   
  cout << "Please enter the third tune:" << endl;
  cin >> tune3;
    if(isValidTune(tune3)== false){
     do{
       cout << "Invalid input. Please enter a tune in valid SPN:" << endl;
       cin >> tune3;
   }while(isValidTune(tune3) != true);
    }
   cout << "Please enter the target tune:" << endl;
   cin >> targetTune;
   //Prints out the oder of the tunes
printTuneRankings(tune1, tune2, tune3 , targetTune);
   
   
   break;
   //Fourth option 
   case 4:
   //Ends loop and Stops code
   cout << "Goodbye!" << endl;
   return 0;
   
}
//if the input was out of the 1-4 range
}else{
    cout << "Invalid Input." << endl;
}
}



}