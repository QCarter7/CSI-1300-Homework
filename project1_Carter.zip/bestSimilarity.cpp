// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Project 1 - Problem 5

#include <iostream>

using namespace std; 



double tuneSimilarity(string tune1, string tune2){
float count = 0;
float diff = 0;
float match = 0;
float o = 0;
float final = 0;

if(tune1.length() == tune2.length()){
    for(int i = 0; i<tune1.length(); i+=2){
        
        if(tune1.substr(i,2) == tune2.substr(i,2)){
            count++;
            match++;
        }
            if(tune1.substr(i,1) == tune2.substr(i,1) && tune1.substr(i+1,1) != tune2.substr(i+1,1)){
                match++;
            }else if(tune1.substr(i,1) != tune2.substr(i,1) && tune1.substr(i+1,1) != tune2.substr(i+1,1)){
            diff--;
            }

}
}else{
    return 0;
}
o = tune1.length()/2;
final += (match/o)+count+diff;
return final;
}

double bestSimilarity(string inputTune, string targetTune){
    double original=-100000;
    double new_high; 
    if(inputTune.length()>=targetTune.length()){   
        for(int i = 0; i<=(inputTune.length()-targetTune.length()); i++){
            
         new_high = tuneSimilarity(inputTune.substr(i,targetTune.length()),targetTune);    
if(new_high>original){
    original = new_high;
}
        }
        }else{
        return 0;
    }  
return original;
}


int main(){
string inputTune;
string targetTune;

cout << "Please enter inputTune:" << endl;
cin >> inputTune;

cout << "Please enter targetTune:" << endl;
cin >> targetTune;

cout << bestSimilarity(inputTune, targetTune) << endl;

}