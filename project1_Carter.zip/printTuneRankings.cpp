// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Project 1 - Problem 6

#include <iostream>
#include <algorithm>
using namespace std;

//compares two scores to see how similar they are
double tuneSimilarity(string tune1, string tune2){
float count = 0;
float diff = 0;
float match = 0;
float o = 0;
float final = 0;

if(tune1.length() == tune2.length()){
    for(int i = 0; i<tune1.length(); i+=2){
        
        if(tune1.substr(i,2) == tune2.substr(i,2)){
            count++;
            match++;
        }
            if(tune1.substr(i,1) == tune2.substr(i,1) && tune1.substr(i+1,1) != tune2.substr(i+1,1)){
                match++;
            }else if(tune1.substr(i,1) != tune2.substr(i,1) && tune1.substr(i+1,1) != tune2.substr(i+1,1)){
            diff--;
            }

}
}else{
    return 0;
}
o = tune1.length()/2;
final += (match/o)+count+diff;
return final;
}

//Gives best score similarity
double bestSimilarity(string inputTune, string targetTune){
    double original=-100000;
    double new_high; 
    if(inputTune.length()>=targetTune.length()){   
        for(int i = 0; i<=(inputTune.length()-targetTune.length()); i++){
            
         new_high = tuneSimilarity(inputTune.substr(i,targetTune.length()),targetTune);    
if(new_high>original){
    original = new_high;
}
        }
        }else{
        return 0;
    }  
return original;
}

//orders the tunes by using their best similarity scores
string printTuneRankings(string tune1, string tune2, string tune3, string targetTune){
   double tune1_score = 0;
   double tune2_score = 0;
   double tune3_score = 0;
  
   string sentence;
  
   
      tune1_score = bestSimilarity(tune1, targetTune);
       tune2_score = bestSimilarity(tune2, targetTune);
        tune3_score = bestSimilarity(tune3, targetTune);
        
    
    double arr[] ={tune1_score, tune2_score,tune3_score};
 int len = sizeof(arr)/sizeof(arr[0]);
sort(arr, arr+len);



if(tune1_score == arr[2] && tune2_score == arr[1] && tune3_score == arr[0] && tune1_score != tune2_score){
    sentence = "1) Tune 1, 2) Tune 2, 3) Tune 3";
}
if(tune1_score == arr[0] && tune2_score == arr[1] && tune3_score == arr[2] && tune1_score != tune2_score){
    sentence = "1) Tune 3, 2) Tune 2, 3) Tune 1";
}
if(tune1_score == arr[2] && tune2_score == arr[0] && tune3_score == arr[1] && tune1_score != tune2_score){
    sentence = "1) Tune 1, 2) Tune 2, 3) Tune 3";
}
if(tune1_score == arr[2] && tune2_score == arr[0] && tune3_score == arr[1] && tune1_score == tune3_score){
    sentence = "1) Tune 1, 2) Tune 3, 3) Tune 2";
}
if(tune1_score == arr[2] && tune2_score == arr[1] && tune3_score == arr[0] && tune1_score == tune3_score){
    sentence = "1) Tune 1, 2) Tune 2, 3) Tune 3";
}
if(tune1_score == arr[2] && tune2_score == arr[0] && tune3_score == arr[1] && tune1_score != tune2_score){
    sentence = "1) Tune 1, 2) Tune 3, 3) Tune 2";
}
if(tune1_score == arr[2] && tune2_score == arr[0] && tune3_score == arr[1] && tune2_score == tune3_score){
    sentence = "1) Tune 1, 2) Tune 2, 3) Tune 3";
}
if(tune1_score == arr[1] && tune2_score == arr[0] && tune3_score == arr[2] && tune1_score == tune2_score){
    sentence = "1) Tune 1, 2) Tune 2, 3) Tune 3";
}
if(tune1_score == arr[2] && tune2_score == arr[1] && tune3_score == arr[0] && tune1_score == tune2_score && tune1_score != tune3_score){
    sentence = "1) Tune 1, 2) Tune 2, 3) Tune 3";
}
if(tune1_score == arr[1] && tune2_score == arr[0] && tune3_score == arr[2] && tune1_score == tune2_score && tune1_score != tune3_score){
    sentence = "1) Tune 3, 2) Tune 1, 3) Tune 2";
}
if(tune1_score == arr[1] && tune2_score == arr[2] && tune3_score == arr[0] && tune1_score == tune3_score && tune1_score != tune2_score ){
    sentence = "1) Tune 2, 2) Tune 1, 3) Tune 3";
}



return sentence;
}


//Checks a note ( A note is A-G and 0-9 ex: A7)
int isValidNote(string note){
   
    if(note.length() <= 2 ){

if(note[0] == 'D' || note[0] == 'A'|| note[0] == 'B' || note[0] == 'C'||  note[0] == 'E'|| note[0] == 'F'|| note[0] == 'G'){
    return true;
   
}else{
    return false;
}


    }else{
        return false;
    }
}

//Checks the entire length of the tune by using isValidNote
bool isValidTune(string note){
    bool Final = true;
for (int i=0; i<note.length(); i+=2){


if(isValidNote(note.substr(i,2)) == true){
    Final = true;
}else{
 return false;
}
}
return Final;
}


int main(){
    //Variables 
string tune1;
string tune2;
string tune3;
string targetTune;

  
   //Gets input and checks if there valid tunes
   cout << "Please enter the first tune:" << endl;
   cin >> tune1;
   if(isValidTune(tune1)== false){
   do{
       cout << "Invalid input. Please enter a tune in valid SPN:" << endl;
       cin >> tune1;
   }while(isValidTune(tune1) == false);
   }
   cout << "Please enter the second tune:" << endl;
   cin >> tune2;
      if(isValidTune(tune2)== false){
     do{
       cout << "Invalid input. Please enter a tune in valid SPN:" << endl;
       cin >> tune2;
   }while(isValidTune(tune2) != true);
      }
   
  cout << "Please enter the third tune:" << endl;
  cin >> tune3;
    if(isValidTune(tune3)== false){
     do{
       cout << "Invalid input. Please enter a tune in valid SPN:" << endl;
       cin >> tune3;
   }while(isValidTune(tune3) != true);
    }
   cout << "Please enter the target tune:" << endl;
   cin >> targetTune;
   
cout << printTuneRankings(tune1, tune2, tune3 , targetTune) << endl;
}