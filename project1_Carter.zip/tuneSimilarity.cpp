// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Project 1 - Problem 4


#include <iostream>

using namespace std;

//Checks to see how similar two tunes are and gives back a score
double tuneSimilarity(string tune1, string tune2){
float count = 0;
float diff = 0;
float match = 0;
float o = 0;
float final = 0;

if(tune1.length() == tune2.length()){
    for(int i = 0; i<tune1.length(); i+=2){
        
        if(tune1.substr(i,2) == tune2.substr(i,2)){
            count++;
            match++;
        }
            if(tune1.substr(i,1) == tune2.substr(i,1) && tune1.substr(i+1,1) != tune2.substr(i+1,1)){
                match++;
            }else if(tune1.substr(i,1) != tune2.substr(i,1) && tune1.substr(i+1,1) != tune2.substr(i+1,1)){
            diff--;
            }

}
}else{
    return 0;
}
o = tune1.length()/2;
final += (match/o)+count+diff;
return final;
}

int main(){
    //variables
string tune1;
string tune2;

//gets user input
cout << "Please enter tune 1:" << endl;
cin >> tune1;

cout << "Please enter tune 2:" << endl;
cin >> tune2;

//display return from funciton 
cout << tuneSimilarity(tune1, tune2) <<  endl;



}

