// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Project 1 - Problem 1


#include <iostream>

using namespace std;


//Checks a note ( A note is A-G and 0-9 ex: A7)
int isValidNote(string note){
   
    if(note.length() <= 2 ){

if(note[0] == 'D' || note[0] == 'A'|| note[0] == 'B' || note[0] == 'C'||  note[0] == 'E'|| note[0] == 'F'|| note[0] == 'G'){
   if(note[1] == '4' || note[1] == '1' || note[1] == '3' || note[1] == '2' || note[1] == '5' || note[1] == '6' || note[1] == '7' || note[1] == '8' || note[1] == '9'      ){
    
    return true;
   }else{
    return false;
   }
}else{
    return false;
}


    }else{
        return false;
    }
}




int main(){
    //variables 
string note;
    cin >> note;
    //displays return value of function 
    isValidTune(note);
    
}