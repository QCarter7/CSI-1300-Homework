// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 5 - Problem 2


#include <iostream>
#include <iomanip>
using namespace std;
//finds min value of array
double min(double arr[], int arr_size){
    double count = 1000;
    
   for(int i = 0; i<arr_size; i++){
       if(arr[i]<count){
         count = arr[i]; 
       }
        
   }
   return count;
}
//adds up all values in array
double sum(double arr[], int arr_size){
  double count = 0;
  
   for(int i = 0; i<arr_size; i++){
      count += arr[i];
   }
   return count;
}

//divides sum by size of array
double average(double arr[], int arr_size){
   double count = 0;
   
   for(int i = 0; i<arr_size; i++){
      count += arr[i];
   }
   count /= arr_size;
   return count;
   
}


int main(){
   //varialbes 
      int arr_size = 3;
    int len = arr_size;
    double arr[3];
    //input values in array
  for(int q = 0; q<arr_size; q++){
    cin >> arr[q];
}
//display each 
cout << "Min: " << fixed << setprecision(3)<< min(arr, len) << endl;
cout << "Sum: " << fixed << setprecision(3) << sum(arr, len) << endl;
cout << "Avg: " << fixed << setprecision(3) << average(arr, len) << endl;

}
