// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 5 - Problem 4

int split(string testcase, char separator, string arr[], int size){
int count= 0;
int second = 0;

//to see if there is a string to test
if(testcase.length() == 0){
    return 0;
}
for(int j = 0; j<testcase.length(); j++ ){
    //if seperator is found in the string add to how many seporators there is
     if(separator ==testcase[j]){
         second++;
     }
}


//if you find seperpator for the given amount of times then add to count
for(int i = 0; i<testcase.length(); i++ ){
    if(separator ==testcase[i]&&count!=size){
        count++;
        i+=1;
    }
    //return conunt of seporators 
     arr[count] += testcase[i];
}
//return values if there more seporators left 
if(count+1>size){
    return -1;
//return value if they are no more seporators to sperorate. 
}else if(count>=0){
    return count+1;
}
}