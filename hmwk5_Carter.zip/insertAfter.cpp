// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 5 - Problem 3a


#include <iostream>

using namespace std;

bool insertAfter(string inputStrings[],int numElements, int size,int index,string stringToInsert){

//Checks to see if the are open array spots
if(size<=numElements){
    return false;
}
//checks to see if index is in the size of array
 if(index>=size){
     return false;
}
//going backwars in the array move everything up 1
 for(int i = numElements-1; i>index; i--){

       inputStrings[i+1] = inputStrings[i];
     }
     //once everything is moved up out in the new string in the array
     inputStrings[index+1] = stringToInsert;
     
     return true;
}





int main(){
int size = 5;
string input_strings[5] = {"pikachu", "meowth", "snorlax"};
int num_elements = 3;
int index = 2;
string string_to_insert = "clefairy";
// result contains the value returned by insertAfter
bool result = insertAfter(input_strings, num_elements, size, index, string_to_insert);
// print result
cout << "Function returned value: "<< result << endl;
// print array contents
for(int i = 0; i < size; i++)
{
    cout << input_strings[i] << endl;
}


    
}