// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 5 - Problem 3b


bool insertAfter(string inputStrings[],int numElements, int size,int index,string stringToInsert){

//Checks to see if the are open array spots
if(size<=numElements){
    return false;
}
//checks to see if index is in the size of array
 if(index>=size){
     return false;
}
//going backwars in the array move everything up 1
 for(int i = numElements-1; i>index; i--){

       inputStrings[i+1] = inputStrings[i];
     }
     //once everything is moved up out in the new string in the array
     inputStrings[index+1] = stringToInsert;
     
     return true;
}





int secondPlace(string inputStrings[], string stringToInsert, string stringToFind, int numElements, int size, int count){
int index;
//itterates the insertafter function for eveytime we find the stringtfind 
if(size<=numElements){
    return numElements;
}
  if(count+numElements >size){
    return numElements;
}
//repeats throught whole array
 for(int i = 0; i<numElements; i++){
    
       if(inputStrings[i] == stringToFind){
           index = i;
      insertAfter(inputStrings, numElements,size,index,stringToInsert);
numElements++;
       }
     }


     return numElements;
}

int main(){

}