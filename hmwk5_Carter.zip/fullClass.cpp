// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 5 - Problem 5


int fullClass(bool classroom[][4], int rows, int waitlist){

//switches placement for rows and collums
for(int i = 0; i<rows;i++){
    for(int j = 0; j<4; j++){

      
        //if 0 is found change to one and subtract from waitlist
        //if waitlist if empty it will stop replacing 0 with 1
   if(classroom[i][j] == 0 && waitlist>0){
     classroom[i][j] = 1;
     waitlist--;
    }
 
 

}
//prints out every row with new changes 
   cout << classroom[i][0]<< classroom[i][1]<<classroom[i][2]<< classroom[i][3]<<endl;    
}
//returns the rest of the students to waitlist 
 cout<< "Remaining Students: " << waitlist <<endl;
}