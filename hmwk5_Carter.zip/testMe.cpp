// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 5 - Problem 6
#include <iostream>
#include <cassert>
using namespace std;

int zeroesToFives(int arr[], int arr_size)
{

	int count = 0;
	//loops through input array
	for(int i = 0; i < arr_size; i++) 
	{ 
        assert(i != i-1);
        
		if(arr[i] == 0) //if an element is zero, set it to five
		{ 
    			arr[i] = 5;
			count++;
             assert (arr[i] != 0);
		}
    
    
	}
     assert (arr[arr_size-1] == 5);
     assert (arr[0] == 5);
      assert (arr[1] == 5);
    assert(count == arr_size);
	return count;
}
int main(){
int arr[5] = {0,0,0,0,0};
int arr_size = 5;

cout << zeroesToFives( arr,  arr_size) << endl;

}
