// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 5 - Problem 1


#include <iostream> 
using namespace std;

int main(){

//Distance Array
int arr[10] {5,6,7,8,9,10,11,12,13,14};
    for(int i = 0; i<10; i++){

cout << arr[i] << endl;
    }

//Cities Array
  string City[5]{"Boulder","NYC","LA","Chicago","Houston"};
for(int j = 0; j<5; j++){

cout << City[j] << endl;
    }

//Sequence Array
int seq[100];
//For every q multiply by 6
for(int q = 1; q<=100; q++){
seq[q] = q*6;
cout << seq[q] << endl;
    }

//Uppercase lowercase alphabet
    int aplha[52];
    for(int c = 0; c<26; c++){
        aplha[c] = 65+c;
        cout << static_cast<char>(aplha[c]) << endl;
        aplha[c] = 97+c;
        cout << static_cast<char>(aplha[c]) << endl;
    }
}