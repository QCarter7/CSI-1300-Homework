// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 4 - Problem 2



#include <iostream>

using namespace std; 

int main(){
 //variables
 int a; 


//Constant loop 
 while(true){
    //First step of loop
  cout <<"Enter  a value between 1 and 1000:" << endl; 
cin >> a;

//checks if a is between 1 and 1000
if (a>1 && a < 1000){
cout << a << endl;

//loop until a is 1 
    while (a != 1){
        //even numbers 
if( a % 2 == 0){
a /= 2;
cout << a << endl;
        //odd numbers 
}else if (a % 2 != 0){
   a= (a*3)+1;
   cout << a << endl;
}else if(a == 1){
    break;
}
    }
break;
//if a is negative, 0, or above 1000
}else{
    cout << "Invalid input."<< endl;
}
 }
 return 0;
}
