// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 4 - Problem 5




#include <iostream>
#include <cmath>

using namespace std;

//Function to repeat alpha bet
string infinite(string letters){
string abc2 = "abcdefghijklmnopqrstuvwxyz";
for(int j = 0; j<10000; j++){
    letters+= abc2;
}
    return letters;
}


int main(){

    //Variables 
int height = 0;
string letters = "abcdefghijklmnopqrstuvwxyz";
string letters_loop;
letters_loop = infinite(letters);

cout << "Enter the height:" << endl;
cin >> height;


//Makes triangle
if(height>0){
 
//tells how may times it should repeat
 for( int i = 1; i<(height*2); i+=2){
    
 cout << letters_loop.substr(0,i) << endl;
 
 letters_loop = letters_loop.substr(i);

 }
}else{
    cout << "Invalid input." << endl;
}
return 0;
}