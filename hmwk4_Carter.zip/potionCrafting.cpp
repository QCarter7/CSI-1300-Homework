// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 4 - Problem 3






#include <iostream> 

using namespace std; 

int main(){

//Variables
char user_selection;

int honey = 0;
int honey_cost = 0;

int dande = 0;
int dande_cost = 0;

int coal = 0;
int coal_cost = 0;


int toad =0;
int toad_cost = 0;

int mana = 0;
int health = 0;



//asks user which potion they will want to make
cout << "Select a potion crafting priority:\n1. Minor Mana\n2. Minor Healing" << endl;
cin >> user_selection;

while(true){
    //checks if user input is 1 or 2 (everything else go default)
switch(user_selection){
    case '1': break;
case '2': break;
default: cout << "Invalid input. \nSelect a potion crafting priority:\n1. Minor Mana\n2. Minor Healing" << endl;
cin >> user_selection; break;
}
break;
}

//user input for honeycombs 
cout << "How many Honeycombs do you have?" << endl;
cin >> honey;
//checks if honey is positve 
while(honey<0){
cout << "Invalid input. How many Honeycombs do you have?" << endl;
cin >> honey;
}

//user input for dandelions 
cout << "How many Dandelions do you have?" << endl;
cin >> dande;
//cecks if dandelions is positive
while(dande<0){
cout << "Invalid input. How many Dandelions do you have?" << endl;
cin >> dande;
}

//user input for coal
cout<< "How many Coal do you have?" << endl;
cin >> coal;
//checks if coal is positve 
while (coal<0){
    cout << "Invalid input. How many Coal do you have?" << endl;
    cin >> coal;
}

//user input for toadstools 
cout << "How many Toadstools do you have?" << endl;
cin >> toad; 
//checks if Toadstools is positive
while (toad<0){
    cout << "Invalid input. How many Toadstools do you have?" << endl;
    cin >> toad;
}

//computes starting with mana
while(true){
switch(user_selection){
case '1':
honey_cost = 5;
dande_cost = 3;
coal_cost = 1;
toad_cost = 0;
while(honey>=honey_cost && dande>=dande_cost && coal>=coal_cost && toad>= toad_cost){
mana += 1;
honey -= honey_cost;
dande -= dande_cost;
coal -= coal_cost;
toad -= toad_cost;
}
//switches to other potion
if (honey>=0 || dande >= 0 || coal >=0 || toad>= 0 ){
honey_cost = 5;
dande_cost = 0;
coal_cost = 2;
toad_cost = 3;

while (honey>=honey_cost && dande>=dande_cost && coal>=coal_cost && toad>= toad_cost)
{
health +=1;
honey -= honey_cost;
dande -= dande_cost;
coal -= coal_cost;
toad -= toad_cost;
}

break;
}

//computes starting with health
case '2': 
honey_cost = 5;
dande_cost = 0;
coal_cost = 2;
toad_cost = 3;
while(honey>=honey_cost && dande>=dande_cost && coal>=coal_cost && toad>= toad_cost){
health += 1;
honey -= honey_cost;
dande -= dande_cost;
coal -= coal_cost;
toad -= toad_cost;
}
//switches to other potion
if (honey>=0 || dande >= 0 || coal >=0 || toad>= 0 ){
honey_cost = 5;
dande_cost = 3;
coal_cost = 1;
toad_cost = 0;

while (honey>=honey_cost && dande>=dande_cost && coal>=coal_cost && toad>= toad_cost)
{
mana +=1;
honey -= honey_cost;
dande -= dande_cost;
coal -= coal_cost;
toad -= toad_cost;
}

break;
}

break;
}







//Final display (senteces sequence changes)
if(user_selection == '1'){
cout << "You can make " << mana << " Mana potion(s) and " << health << " Healing potion(s)." << endl; break;
}else if (user_selection == '2'){
    cout <<  "You can make " << health << " Healing potion(s) and " << mana << " Mana potion(s)." << endl; break;
}

break;
}


}




