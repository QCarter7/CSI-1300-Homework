// CSCI 1300 Fall 2022
// Author: Quincy Carter
// Recitation: 114 - Michelle Ramsahoye
// Homework 4 - Problem 4



#include <iostream>
#include <string>

using namespace std;

int main(){

//Variables
string dna;
string sub;
int counter = 0;

//Get Input
cout << "Enter the DNA Sequence:" << endl;
getline(cin ,dna);

//Checks if input has these numbers 
for(int j=0; j<dna.length(); j++){
if(dna[j] != 'G' && dna[j] != 'A' && dna[j] != 'T' && dna[j] != 'C'){
cout << "This is not a valid DNA sequence." << endl;
return 0;
}
}
//Checks if input by user is a real fragment
 cout << "Enter the DNA fragment to be searched:" << endl;
getline(cin,sub); 
for(int q = 0; q < sub.length(); q++){
  if(sub[q] != 'G' && sub[q] != 'T' && sub[q] != 'A' && sub[q] != 'C'){
  cout << "This is not a valid DNA sequence" << endl;
  return 0;
}
}

//Count if there are any matches
for (int i = 0; i<= dna.length(); i++){
if(dna.substr(i,sub.length()) == sub){
    counter++;
}
}
cout << "Number of occurrences: " << counter << endl;
}















